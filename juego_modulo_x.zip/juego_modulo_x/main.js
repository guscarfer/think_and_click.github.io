let resultElement = document.querySelector('.result');
let mainContainer = document.querySelector('.main-container');
let rowId = 1;

//peticion a la api de palabras

fetch ('https://clientes.api.greenborn.com.ar/public-random-word?c=1')
.then(result => result.json())
.then(data => {
    console.log(data);
    let word = data[0];
    //split crea un corte en la letra que se le pase, en ste caso retorna te  to. corto en la x
    let wordArray = word.toUpperCase().split('');
    //console.log(wordArray);
    
    let actualRow = document.querySelector('.row');
    
    drawSquares(actualRow);
    listenInput(actualRow);
    
    addfocus(actualRow);
    
    
    //funciones
    function listenInput(actualRow){
        let squares = actualRow.querySelectorAll('.square');
        squares = [...squares];//se recorren los elementos y los agrega en un arreglo
    
        console.log(squares);
        //se guardan las letras ingresadas en el arreglo userInput
        let userInput = [];
        squares.forEach(Element => {
            Element.addEventListener('input', (event) => {
                //si no se ha borrado
                if(event.inputType !== 'deleteContentBackward'){
                    //recoger el ingreso del usuario
                    userInput.push(event.target.value.toUpperCase());
                    
                    if(event.target.nextElementSibling){
                        //cambia de casilla al insertar una letra, si no hay mas casillas disponibles pasa al else
                        event.target.nextElementSibling.focus();
                    }else{
                        //arreglo con las letras llenas
                        let squaresFilled = document.querySelectorAll('.square');
                        squaresFilled = [...squaresFilled]
                        let lastFivesquaresFilled = squaresFilled.slice(-word.length);
                        let finalUserInput = [];
                        lastFivesquaresFilled.forEach(Element => {
                            finalUserInput.push(Element.value.toUpperCase());
                        })
                        //console.log(finalUserInput);
    
                        //comparacion de arreglos para cambiar estilos
                        let rightIndex = compareArrays(wordArray, finalUserInput);
                        rightIndex.forEach(Element => {
                            squares[Element].classList.add('green');
                        });
            
                        //si los arreglos son iguales
                        if(rightIndex.length == wordArray.length){
                            showResult('Ganaste!');
                            return;//al acertar la palabra sale de la funcion y ya no genera una nueva linea
                        }
                        //cambiar estilos si existe la letra pero no esta en la posicion correcta
                        let existIndexArray = existLetters(wordArray, finalUserInput)
                        existIndexArray.forEach(Element => {
                            squares[Element].classList.add('gold');
                        });
                        //console.log(existIndexArray);
            
                        //crear nueva fila
                        let actualRow = createRow();
    
                        if(!actualRow){
                            return;
                        }
                        console.log(actualRow);
                        drawSquares(actualRow);
                        listenInput(actualRow);
                        addfocus(actualRow);
                    }
                }else{
                    userInput.pop();
                }
                //console.log(userInput);
            });
        });
    }
    
    /* el arreglo2 es lo que el usuario ingreso */
    function compareArrays(array1, array2){
        let iqualsIndex = []
        array1.forEach((Element, index) => {
            if(Element == array2[index]){
                console.log(`En la posicion ${index} si son iguales`);
                iqualsIndex.push(index);
            }else{
                console.log(`En la posicon ${index} no son iguales`);
            }
        });
        return iqualsIndex;
    }
    
    function existLetters(array1, array2){
        let existIndexArray = [];
        array2.forEach((Element, index) => {
            if (array1.includes(Element)){
                existIndexArray.push(index);
            }
        });
        return existIndexArray;
    }
    
    function createRow(){
        rowId ++;
        if(rowId <= 5){
            let newRow = document.createElement('div');
            newRow.classList.add('row');
            newRow.setAttribute('id', rowId);
            mainContainer.appendChild(newRow);
            return newRow;
        }else{
            showResult(`Perdiste, intentalo de nuevo :{ \n La respuesta correcta era "${word.toUpperCase()}"`);
        }
    
    }
    
    function drawSquares(actualRow){
        //se van generando campos de texto en base a la cantidad de letras de la palabra
        wordArray.forEach((item, index) => {
            if(index === 0){
                actualRow.innerHTML += `<input type="text" maxLength="1" class="square" autofocus>`;
            }else{
                actualRow.innerHTML += `<input type="text" maxLength="1" class="square">`;
            }
        });
    }
    
    function addfocus(actualRow){
        let focusElement = actualRow.querySelector('.square[autofocus]');
        console.log(focusElement);
        focusElement.focus();
    }
    
    function showResult(textMsg){
        resultElement.innerHTML = `<p>${textMsg}</p>
        <button class="button">Reiniciar</button>`;
    
        let resetBtn = document.querySelector('button');
        resetBtn.addEventListener('click', ()=>{
            location.reload();
        });
    }
})

